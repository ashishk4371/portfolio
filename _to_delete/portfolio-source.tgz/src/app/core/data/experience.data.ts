import { Education, Experience } from '../models';

export const EXPERIENCES: readonly Experience[] = [
  {
    id: 'northwind',
    company: 'Northwind Labs',
    companyUrl: 'https://example.com',
    role: 'Senior Full-Stack Engineer',
    type: 'Full-time',
    startDate: '2023-04-01',
    endDate: null,
    location: 'Bengaluru · Hybrid',
    summary:
      'Technical lead for the customer-facing platform, covering the Angular application, its BFF layer and the release pipeline behind both.',
    highlights: [
      'Migrated a 240-component Angular application to standalone components and signals, cutting the initial bundle by 38% and removing zone.js entirely.',
      'Designed a BFF in NestJS that collapsed 11 client-side round trips into a single hydrated payload, taking p75 LCP from 4.1s to 1.3s.',
      'Introduced performance budgets and Lighthouse CI as a merge gate, which has held the score above 95 for eighteen months.',
      'Mentored four engineers through the migration and wrote the internal signals guide the team still onboards with.',
    ],
    stack: ['Angular', 'TypeScript', 'NestJS', 'PostgreSQL', 'AWS', 'GitHub Actions'],
  },
  {
    id: 'lumen',
    company: 'Lumen Retail',
    role: 'Full-Stack Engineer',
    type: 'Full-time',
    startDate: '2021-01-01',
    endDate: '2023-03-31',
    location: 'Remote',
    summary:
      'Built the checkout and fulfilment surfaces for a commerce platform serving roughly 300k monthly orders.',
    highlights: [
      'Rebuilt checkout as a resumable, offline-tolerant flow; cart abandonment dropped 11 points in the first quarter.',
      'Owned the move from a single Postgres instance to read replicas plus Redis caching, absorbing a 4x traffic increase without new hardware.',
      'Wrote the idempotency layer for payment webhooks that ended a long-running class of duplicate-charge incidents.',
    ],
    stack: ['React', 'Node.js', 'PostgreSQL', 'Redis', 'Stripe', 'Docker'],
  },
  {
    id: 'brightfold',
    company: 'Brightfold Studio',
    role: 'Frontend Engineer',
    type: 'Full-time',
    startDate: '2019-07-01',
    endDate: '2020-12-31',
    location: 'Pune · On-site',
    summary:
      'Delivered client web applications across fintech and healthcare, most of them under regulatory accessibility requirements.',
    highlights: [
      'Shipped fourteen client projects, six of them audited to WCAG 2.1 AA with no outstanding findings.',
      'Built the studio component library that became the default starting point for every new engagement.',
    ],
    stack: ['Angular', 'TypeScript', 'SCSS', 'Jest', 'Figma'],
  },
];

export const EDUCATION: readonly Education[] = [
  {
    id: 'btech',
    institution: 'Vellore Institute of Technology',
    qualification: 'B.Tech, Computer Science & Engineering',
    startYear: 2015,
    endYear: 2019,
    detail: 'Graduated with distinction. Final-year work on distributed cache invalidation.',
  },
];
